import SwiftUI
import UIKit

/// Shows the connect screen until a computer address is saved, then the app itself.
struct ContentView: View {
    @AppStorage("serverURL") private var serverURL: String = ""
    @State private var editing = false

    var body: some View {
        Group {
            if serverURL.isEmpty || editing {
                ConnectView(
                    current: serverURL,
                    canCancel: !serverURL.isEmpty,
                    onConnected: { url in
                        serverURL = url
                        editing = false
                    },
                    onCancel: { editing = false }
                )
            } else {
                BrowserScreen(urlString: serverURL, onChangeServer: { editing = true })
                    .id(serverURL)
            }
        }
        .onAppear {
            // Keep the phone awake so long uploads and jobs are not interrupted by auto-lock.
            UIApplication.shared.isIdleTimerDisabled = true
        }
    }
}

// MARK: - Connect screen

struct ConnectView: View {
    let current: String
    let canCancel: Bool
    let onConnected: (String) -> Void
    let onCancel: () -> Void

    @State private var address: String = ""
    @State private var busy: Bool = false
    @State private var message: String? = nil

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("192.168.1.23:8000", text: $address)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled(true)
                        .submitLabel(.go)
                        .onSubmit { Task { await connect() } }
                } header: {
                    Text("Your computer's address")
                } footer: {
                    Text("On the computer, double-click start-phone.bat. The black window shows an address like 192.168.1.23:8000. Type it here. The iPhone must be on the same Wi-Fi.")
                }

                if let message = message {
                    Section {
                        Text(message).foregroundColor(.red)
                    }
                }

                Section {
                    Button {
                        Task { await connect() }
                    } label: {
                        HStack {
                            Text("Connect")
                            Spacer()
                            if busy { ProgressView() }
                        }
                    }
                    .disabled(busy || address.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .navigationTitle("Shorts Maker")
            .toolbar {
                if canCancel {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") { onCancel() }
                    }
                }
            }
            .onAppear {
                if address.isEmpty { address = current }
            }
        }
    }

    @MainActor
    private func connect() async {
        busy = true
        message = nil
        defer { busy = false }

        guard let base = ConnectView.normalize(address),
              let url = URL(string: base + "/api/health") else {
            message = "That address doesn't look right. Example: 192.168.1.23:8000"
            return
        }
        var request = URLRequest(url: url)
        request.timeoutInterval = 8
        do {
            let (_, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, http.statusCode == 200 || http.statusCode == 401 {
                onConnected(base)   // 401 means the server is there but wants an API key; the page asks for it
            } else {
                message = "Something answered, but it isn't Shorts Maker. Check the address and the port number."
            }
        } catch let error as URLError {
            message = ConnectView.explain(error)
        } catch {
            message = error.localizedDescription
        }
    }

    static func normalize(_ raw: String) -> String? {
        var s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if s.isEmpty { return nil }
        let lower = s.lowercased()
        if !(lower.hasPrefix("http://") || lower.hasPrefix("https://")) {
            let isLocal = lower.range(of: #"^(\d{1,3}\.){3}\d{1,3}(:\d+)?"#, options: .regularExpression) != nil
                || lower.hasPrefix("localhost")
                || lower.contains(".local")
                || !lower.contains(".")
            s = (isLocal ? "http://" : "https://") + s
        }
        while s.hasSuffix("/") { s.removeLast() }
        guard let parts = URLComponents(string: s), let host = parts.host, !host.isEmpty else { return nil }
        return s
    }

    static func explain(_ error: URLError) -> String {
        switch error.code {
        case .timedOut, .cannotConnectToHost, .cannotFindHost, .networkConnectionLost:
            return "Couldn't reach the computer. Check that the app is running there (start-phone.bat), that both devices use the same Wi-Fi, that Windows Firewall allowed it, and that Shorts Maker has Local Network access in iPhone Settings."
        case .notConnectedToInternet:
            return "No network connection. Connect the iPhone to Wi-Fi."
        default:
            return error.localizedDescription
        }
    }
}
