import SwiftUI
import UIKit
import WebKit

// MARK: - Screen that hosts the web page

struct BrowserScreen: View {
    let urlString: String
    let onChangeServer: () -> Void
    @StateObject private var model = WebModel()

    var body: some View {
        NavigationStack {
            ZStack {
                WebView(model: model, urlString: urlString)

                if let text = model.errorText {
                    VStack(spacing: 16) {
                        Image(systemName: "wifi.exclamationmark")
                            .font(.system(size: 44))
                        Text(text)
                            .multilineTextAlignment(.center)
                        Button("Try again") { model.reload() }
                            .buttonStyle(.borderedProminent)
                        Button("Change computer address", action: onChangeServer)
                    }
                    .padding(24)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(.systemBackground))
                }
            }
            .navigationTitle("Shorts Maker")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button("Reload") { model.reload() }
                        Button("Change computer address", action: onChangeServer)
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
        }
    }
}

final class WebModel: ObservableObject {
    @Published var errorText: String? = nil
    weak var webView: WKWebView?
    var lastURL: URL?

    func reload() {
        errorText = nil
        if let web = webView {
            if web.url == nil, let url = lastURL {
                web.load(URLRequest(url: url))
            } else {
                web.reload()
            }
        }
    }
}

// MARK: - WKWebView wrapper

struct WebView: UIViewRepresentable {
    let model: WebModel
    let urlString: String

    func makeCoordinator() -> Coordinator {
        Coordinator(model: model)
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true

        // Lets the page know it is running inside the app (hides browser-only tips).
        let flag = WKUserScript(source: "window.NATIVE_APP = true;",
                                injectionTime: .atDocumentStart,
                                forMainFrameOnly: true)
        config.userContentController.addUserScript(flag)

        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator
        web.uiDelegate = context.coordinator
        model.webView = web

        if let url = URL(string: urlString) {
            model.lastURL = url
            web.load(URLRequest(url: url))
        }
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    // MARK: Coordinator: navigation, JavaScript dialogs and downloads

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
        let model: WebModel
        private var destinations: [ObjectIdentifier: URL] = [:]

        init(model: WebModel) {
            self.model = model
        }

        // Navigation ---------------------------------------------------------

        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if navigationAction.shouldPerformDownload {
                decisionHandler(.download)     // links with a "download" attribute (clips, zip)
            } else {
                decisionHandler(.allow)
            }
        }

        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationResponse: WKNavigationResponse,
                     decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
            decisionHandler(navigationResponse.canShowMIMEType ? .allow : .download)
        }

        func webView(_ webView: WKWebView,
                     navigationAction: WKNavigationAction,
                     didBecome download: WKDownload) {
            download.delegate = self
        }

        func webView(_ webView: WKWebView,
                     navigationResponse: WKNavigationResponse,
                     didBecome download: WKDownload) {
            download.delegate = self
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.async { self.model.errorText = nil }
        }

        func webView(_ webView: WKWebView,
                     didFailProvisionalNavigation navigation: WKNavigation!,
                     withError error: Error) {
            report(error)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            report(error)
        }

        private func report(_ error: Error) {
            let ns = error as NSError
            if ns.code == NSURLErrorCancelled { return }
            if ns.domain == "WebKitErrorDomain" && ns.code == 102 { return }   // load became a download
            DispatchQueue.main.async {
                self.model.errorText = "Couldn't reach your computer. Make sure the app is running there, you're on the same Wi-Fi, and Local Network is allowed for Shorts Maker in the iPhone Settings app."
            }
        }

        // JavaScript dialogs (the page uses prompt() for the API key and confirm() for delete) ---

        func webView(_ webView: WKWebView,
                     runJavaScriptAlertPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo,
                     completionHandler: @escaping () -> Void) {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
            if !present(alert) { completionHandler() }
        }

        func webView(_ webView: WKWebView,
                     runJavaScriptConfirmPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo,
                     completionHandler: @escaping (Bool) -> Void) {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
            if !present(alert) { completionHandler(false) }
        }

        func webView(_ webView: WKWebView,
                     runJavaScriptTextInputPanelWithPrompt prompt: String,
                     defaultText: String?,
                     initiatedByFrame frame: WKFrameInfo,
                     completionHandler: @escaping (String?) -> Void) {
            let alert = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
            alert.addTextField { field in
                field.text = defaultText
                field.autocapitalizationType = .none
                field.autocorrectionType = .no
            }
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(nil) })
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                completionHandler(alert.textFields?.first?.text)
            })
            if !present(alert) { completionHandler(nil) }
        }

        private func present(_ controller: UIViewController) -> Bool {
            guard let top = Coordinator.topViewController() else { return false }
            top.present(controller, animated: true)
            return true
        }

        static func topViewController() -> UIViewController? {
            let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first
            var top = scene?.windows.first(where: { $0.isKeyWindow })?.rootViewController
            while let next = top?.presentedViewController {
                top = next
            }
            return top
        }

        // Downloads: save to a temporary file, then show the iOS share sheet ("Save Video", "Save to Files") ---

        func download(_ download: WKDownload,
                      decideDestinationUsing response: URLResponse,
                      suggestedFilename: String,
                      completionHandler: @escaping (URL?) -> Void) {
            let folder = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString, isDirectory: true)
            try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let name = suggestedFilename.isEmpty ? "clip.mp4" : suggestedFilename
            let destination = folder.appendingPathComponent(name)
            destinations[ObjectIdentifier(download)] = destination
            completionHandler(destination)
        }

        func downloadDidFinish(_ download: WKDownload) {
            guard let file = destinations.removeValue(forKey: ObjectIdentifier(download)) else { return }
            DispatchQueue.main.async {
                guard let top = Coordinator.topViewController() else { return }
                let sheet = UIActivityViewController(activityItems: [file], applicationActivities: nil)
                if let popover = sheet.popoverPresentationController {   // needed on iPad
                    popover.sourceView = top.view
                    popover.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.midY, width: 1, height: 1)
                    popover.permittedArrowDirections = []
                }
                top.present(sheet, animated: true)
            }
        }

        func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
            destinations.removeValue(forKey: ObjectIdentifier(download))
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Download failed",
                                              message: error.localizedDescription,
                                              preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                Coordinator.topViewController()?.present(alert, animated: true)
            }
        }
    }
}
