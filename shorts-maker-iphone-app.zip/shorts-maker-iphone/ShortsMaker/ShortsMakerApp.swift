import SwiftUI

@main
struct ShortsMakerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
