# Shorts Maker for iPhone (app project)

A real iPhone app that connects to Shorts Maker running on your computer (or on Hugging Face).
It remembers your computer's address, keeps the phone awake during uploads, and opens the iPhone
share sheet for clips, so **Save Video** goes straight to Photos.

**Status: this project has not been compiled or run yet.** It was written without access to Xcode.
If the build fails, copy the red error lines and send them to the person who gave you this
(or to Claude); small fixes are usually quick.

An iPhone app can only be built on macOS. You do not need a Mac: GitHub builds it for you for free.

---

## Route A: no Mac (Windows laptop), about 40 minutes

### Part 1: Build the app on GitHub
1. Make a free account at **github.com**.
2. Click **+** (top right), then **New repository**. Name it `shorts-maker-iphone`.
   Choose **Public** (builds are free for public repositories), then **Create repository**.
3. Click **uploading an existing file**.
4. Open this extracted folder in File Explorer, press **Ctrl + A** to select everything
   (`.github`, `ShortsMaker`, `project.yml`, `README.md`, `.gitignore`), and **drag it all** into the browser page.
   Wait for the upload bars to finish, then click **Commit changes**.
   - If `.github` doesn't upload, click **Add file, then Create new file**, type
     `.github/workflows/build-ios.yml` as the name, paste in the contents of that file from this folder, and commit.
5. Click the **Actions** tab. If it asks, click **I understand my workflows, enable them**.
6. Click **Build iPhone app** on the left, then **Run workflow**, then the green **Run workflow** button.
7. Wait 5 to 10 minutes until the run shows a green tick.
   - A red cross means the build failed. Open the run, click the step with the red cross, and copy the red error lines.
8. Open the finished run, scroll to **Artifacts**, and download **ShortsMaker-ipa**. Extract the zip to get `ShortsMaker.ipa`.

### Part 2: Install it on your iPhone from Windows
The file is unsigned, so a tool must sign it with your Apple ID. A free Apple ID works, but the app **stops opening after 7 days**
and you re-install it the same way. (Check each tool's website for current steps; they change.)
1. Install **iTunes** and **iCloud** from apple.com (the versions from the Microsoft Store do not work with Sideloadly).
2. Install **Sideloadly** from sideloadly.io.
3. Plug the iPhone into the laptop with a cable. Tap **Trust** on the iPhone.
4. Open Sideloadly, drag in `ShortsMaker.ipa`, type your Apple ID, and click **Start**. Enter your password if asked.
5. On the iPhone, go to **Settings, then Privacy & Security, then Developer Mode**, turn it **On**, and restart the phone.
6. Go to **Settings, then General, then VPN & Device Management**, tap your Apple ID, and tap **Trust**.
7. Open **Shorts Maker** from the Home Screen.

(AltStore is an alternative to Sideloadly.)

---

## Route B: you have a Mac with Xcode
1. `brew install xcodegen`
2. In this folder: `xcodegen generate`
3. `open ShortsMaker.xcodeproj`
4. In Xcode, select the **ShortsMaker** target, then **Signing & Capabilities**, and choose your **Team**.
5. Plug in the iPhone, select it at the top, and press **Run**.

---

## Using the app
1. On the computer, run **start-phone.bat** (from the Shorts Maker folder). The black window shows an address like `192.168.1.23:8000`.
2. Open the iPhone app and type that address. Tap **Connect**.
3. The first time, iPhone asks to allow **Local Network** access. Tap **Allow**. (If you tapped Don't Allow, turn it on in
   **Settings, then Shorts Maker, then Local Network**.)
4. Tap **Tap to choose a video**, pick one from Photos, and tap **Make shorts**.
5. Keep the app open while it uploads. When clips appear, tap **Download**, then **Save Video** in the share sheet.
6. To use a different computer, tap the **...** menu at the top right, then **Change computer address**.
   An `https://` address (such as a Hugging Face Space) also works.

## Good to know
- The app is a native shell around the same Shorts Maker page, so it always matches the version running on your computer.
- Publishing to the App Store needs a paid Apple Developer account (about 99 USD a year), and Apple may reject apps that only wrap a website.
- The app only works while your computer is on, awake, and running Shorts Maker in phone mode.
